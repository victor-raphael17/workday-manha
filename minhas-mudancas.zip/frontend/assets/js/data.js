// Static UI chrome. All medication / patient / prescription data now comes from
// the API (see api.js); only the shell's navigation and branch identity live here.

export const branch = {
  name: import.meta.env.VITE_BRANCH_NAME ?? "Unknown Branch",
  shiftLead: import.meta.env.VITE_BRANCH_SHIFT_LEAD ?? "Unknown",
  role: import.meta.env.VITE_BRANCH_ROLE ?? "Unknown",
};

export const navigation = [
  {
    id: "dashboard",
    label: "Dashboard",
    href: "dashboard.html",
    icon: "layout-dashboard",
  },
  {
    id: "inventory",
    label: "Inventory",
    href: "inventory.html",
    icon: "package",
  },
  {
    id: "stock-movements",
    label: "Stock movements",
    href: "stock-movements.html",
    icon: "history",
  },
  {
    id: "pos",
    label: "Point of sale",
    href: "pos.html",
    icon: "shopping-cart",
  },
  {
    id: "prescriptions",
    label: "Prescriptions",
    href: "prescriptions.html",
    icon: "clipboard-list",
  },
  { id: "patients", label: "Patients", href: "patients.html", icon: "users" },
  { id: "orders", label: "Orders", href: "orders.html", icon: "truck" },
];
